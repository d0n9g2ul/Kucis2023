import argparse
import subprocess
import os
import pyExtract.extract

root_directory_path = os.path.dirname(os.path.abspath(__file__))

def create_main_directory(root_directory_path):
    if not os.path.exists(root_directory_path+"/result"):
        os.makedirs(root_directory_path+"/result")
        print("Created result directory: ", root_directory_path + "/result")

def extract_subcommand(args):

    create_main_directory(root_directory_path)
    
    if args.extract_option == None:
        print("[***]\tEXTRACT ALL LOGs !!\t[***]")
        pyExtract.extract.history()
        pyExtract.extract.access_time(None)
        pyExtract.extract.modify_time(None)
        pyExtract.extract.birth_time(None)
        pyExtract.extract.login()
        pyExtract.extract.system()

        print("[***]\tALL DONE\t[***]")

    elif args.extract_option == 'history':
        pyExtract.extract.history()

    elif args.extract_option == 'modify':
        pyExtract.extract.change_time(args.directory)

    elif args.extract_option == 'access':
        pyExtract.extract.access_time(args.directory)

    elif args.extract_option == 'birth':
        pyExtract.extract.birth()

    elif args.extract_option == 'login':
        pyExtract.extract.login()
    
    elif args.extract_option == 'system':
        pyExtract.extract.system()

    elif args.extract_option == 'log':
        extract_log(args.directory, args.target_file, args.keyword)

def analyze_subcommand(args):
    pass

def main():
    parser = argparse.ArgumentParser(description='exDG Log Analyzer Tool')
    subparsers = parser.add_subparsers(title='Subcommands', dest='subcommand')

    extract_parser = subparsers.add_parser('extract', help='Extract File imformation')
    extract_subparsers = extract_parser.add_subparsers(title='Extract options', dest='extract_option')

    #history parser
    history_parser = extract_subparsers.add_parser('history', help='Extract history logs')

    #modifytime parser
    modifytime_parser = extract_subparsers.add_parser('modify', help='Extract file final modify time / Default: home, etc, var, usr')
    modifytime_parser.add_argument('-d', '--directory', default='logs', help='Directory path(s) for extract')

    #accesstime parser
    accesstime_parser = extract_subparsers.add_parser('access', help='Extract file final access time / Default: home, etc, var, usr')
    accesstime_parser.add_argument('-d', '--directory', default='logs', help='Directory path(s) for extract')

    #birthtime parser
    birthtime_parser = extract_subparsers.add_parser('birth', help='Extract file final birth time / Default: home, etc, var, usr')
    birthtime_parser.add_argument('-d', '--directory', default='logs', help='Directory path(s) for extract')

    # login parser
    login = extract_subparsers.add_parser('login', help='Extract Login log: last, lastb')

    #network parser
    system_parser = extract_subparsers.add_parser('system', help='Extract system log (network, process, top)')
    
    ''' 미완성
    system_parser.add_argument('-n', '--network', default='logs', help='Network state extract')
    system_parser.add_argument('-p', '--process', default='logs', help='Process state extract')
    system_parser.add_argument('-t', '--top', default='logs', help='Top state extract')
    '''

    ''' 미완성
    #log parser
    log_parser = extract_subparsers.add_parser('log', help='Extract log files')
    log_parser.add_argument('-a', '--all', help='All log file')
    log_parser.add_argument('-f', '--target-file', help='Target log file')
    log_parser.add_argument('-k', '--keyword', help='Keyword to search in logs')
    '''

    # analyze_parser 코드는 유지

    args = parser.parse_args()

    if args.subcommand == 'extract':
        extract_subcommand(args)
    elif args.subcommand == 'analyze':
        analyze_subcommand(args)
    else:
        parser.print_help()

if __name__ == '__main__':
    main()

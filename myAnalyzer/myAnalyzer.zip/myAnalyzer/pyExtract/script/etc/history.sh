#!/bin/bash

HISTFILE=~/.bash_history
set -o history
history -w result/history.txt
